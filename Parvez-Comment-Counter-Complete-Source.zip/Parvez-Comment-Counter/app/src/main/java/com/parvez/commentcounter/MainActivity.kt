package com.parvez.commentcounter

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 24)
        }
        root.addView(TextView(this).apply {
            text = "Parvez Comment Counter"
            textSize = 25f
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Facebook clone comment counter (পরীক্ষামূলক)"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 24)
        })
        root.addView(Button(this).apply {
            text = "১. Accessibility চালু করুন"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(TextView(this).apply {
            text = "সেটিংসে Installed apps / Downloaded apps থেকে Parvez Comment Counter চালু করুন। এরপর Facebook অ্যাপ খুলুন।"
            textSize = 15f
            setPadding(0, 16, 0, 16)
        })
        val facebookApps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
            .mapNotNull { info ->
                val label = packageManager.getApplicationLabel(info).toString()
                if (label.contains("facebook", true) || info.packageName.contains("facebook", true)) label else null
            }.distinct()
        root.addView(TextView(this).apply {
            text = "Facebook নামে শনাক্ত হওয়া অ্যাপ: ${facebookApps.size}\n\nনোট: সব ক্লোনে কমেন্ট শনাক্তকরণ একইভাবে কাজ নাও করতে পারে।"
            textSize = 15f
            setPadding(0, 12, 0, 12)
        })
        setContentView(root)
    }
}
