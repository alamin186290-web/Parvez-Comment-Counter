package com.parvez.commentcounter

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView

/**
 * Prototype: detects Facebook-labelled apps, resets on app switch, shows a floating count,
 * and attempts conservative confirmation by checking that the submitted text appears
 * outside an editable field after a Post/Send action. Facebook clones may expose different
 * accessibility trees, so this is not a universal or guaranteed success detector.
 */
class CommentAccessibilityService : AccessibilityService() {
    private var activeFacebookPackage: String? = null
    private var commentCount = 0
    private var pendingText: String? = null
    private var overlay: TextView? = null
    private var windowManager: WindowManager? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val packageName = event.packageName?.toString() ?: return
        val isFacebook = isFacebookPackage(packageName)

        if (isFacebook) {
            if (activeFacebookPackage != packageName) {
                activeFacebookPackage = packageName
                commentCount = 0
                pendingText = null
                showOverlay()
                updateOverlay()
                Log.d(TAG, "Facebook app entered: $packageName; count reset")
            }

            if (event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED && looksLikePostAction(event)) {
                val text = findEditableText(rootInActiveWindow)
                if (text.length >= 2) pendingText = text
            }

            if (event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
                event.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
                val candidate = pendingText
                if (!candidate.isNullOrBlank()) {
                    handler.removeCallbacks(verifyPending)
                    handler.postDelayed(verifyPending, VERIFY_DELAY_MS)
                }
            }
        } else if (activeFacebookPackage != null &&
            event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            activeFacebookPackage = null
            commentCount = 0
            pendingText = null
            hideOverlay()
            Log.d(TAG, "Facebook app exited; count reset")
        }
    }

    private val verifyPending = Runnable {
        val candidate = pendingText ?: return@Runnable
        val root = rootInActiveWindow
        if (root != null && containsVisibleNonEditableText(root, candidate)) {
            commentCount += 1
            pendingText = null
            updateOverlay()
            Log.d(TAG, "Possible posted comment confirmed; count=$commentCount")
        }
    }

    private fun isFacebookPackage(packageName: String): Boolean {
        return try {
            val info = packageManager.getApplicationInfo(packageName, 0)
            val label = packageManager.getApplicationLabel(info).toString()
            label.contains("facebook", ignoreCase = true) ||
                packageName.contains("facebook", ignoreCase = true)
        } catch (_: Exception) { false }
    }

    private fun looksLikePostAction(event: AccessibilityEvent): Boolean {
        val words = listOf("post", "send", "publish", "পোস্ট", "প্রকাশ", "পাঠান", "কমেন্ট করুন", "মন্তব্য করুন")
        val description = (event.text?.joinToString(" ") ?: "") + " " + (event.contentDescription ?: "")
        return words.any { description.contains(it, ignoreCase = true) }
    }

    private fun findEditableText(node: AccessibilityNodeInfo?): String {
        if (node == null) return ""
        if (node.isEditable) return node.text?.toString()?.trim().orEmpty()
        for (i in 0 until node.childCount) {
            val found = findEditableText(node.getChild(i))
            if (found.isNotBlank()) return found
        }
        return ""
    }

    private fun containsVisibleNonEditableText(node: AccessibilityNodeInfo?, target: String): Boolean {
        if (node == null) return false
        val text = node.text?.toString()?.trim().orEmpty()
        if (!node.isEditable && text == target) return true
        for (i in 0 until node.childCount) {
            if (containsVisibleNonEditableText(node.getChild(i), target)) return true
        }
        return false
    }

    private fun showOverlay() {
        if (overlay != null) return
        val wm = windowManager ?: return
        val view = TextView(this).apply {
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(24, 14, 24, 14)
            setBackgroundColor(0xDD202124.toInt())
            text = "কমেন্ট: 0"
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 90
        }
        try {
            wm.addView(view, params)
            overlay = view
        } catch (e: Exception) { Log.e(TAG, "Overlay could not be shown", e) }
    }

    private fun updateOverlay() {
        handler.post { overlay?.text = "কমেন্ট: $commentCount" }
    }

    private fun hideOverlay() {
        handler.post {
            try { overlay?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
            overlay = null
        }
    }

    override fun onInterrupt() { Log.d(TAG, "Accessibility interrupted") }

    override fun onDestroy() {
        handler.removeCallbacks(verifyPending)
        hideOverlay()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "ParvezCounter"
        private const val VERIFY_DELAY_MS = 700L
    }
}
