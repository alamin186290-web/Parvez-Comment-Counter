PARVEZ COMMENT COUNTER — পরীক্ষামূলক সোর্স

কী আছে:
- Facebook নাম/প্যাকেজ শনাক্ত করার চেষ্টা
- অন্য অ্যাপে গেলে কাউন্ট শূন্য করা
- Accessibility overlay-তে ভাসমান কাউন্টার
- Post/Send action-এর পর একই লেখা editable field-এর বাইরে দেখা গেলে কাউন্ট বাড়ানোর চেষ্টা

গুরুত্বপূর্ণ সীমাবদ্ধতা:
Facebook এবং প্রতিটি clone-এর Accessibility UI আলাদা হতে পারে। তাই সব clone-এ সফল কমেন্ট ১০০% নির্ভুলভাবে শনাক্ত হবে—এমন নিশ্চয়তা নেই। কিছু clone-এ কমেন্ট পোস্ট হলেও UI text না দিলে কাউন্ট বাড়বে না; আবার একই লেখা অন্য জায়গায় থাকলে ভুল শনাক্ত হওয়ার ঝুঁকি আছে। বাস্তবে পরীক্ষা ছাড়া এটিকে নির্ভুল কাউন্টার বলা যাবে না।

Build:
GitHub Actions থেকে Build Parvez Comment Counter workflow চালান। সফল হলে Artifacts থেকে Parvez-Comment-Counter-APK ডাউনলোড করুন।

ফোনে চালু:
১. APK ইনস্টল করুন।
২. অ্যাপ খুলে Accessibility সেটিংসে যান।
৩. Downloaded/Installed apps তালিকা থেকে Parvez Comment Counter চালু করুন।
৪. Facebook clone খুলে পরীক্ষা করুন।

এই অ্যাপ কোনো UID চায় না। এটি অ্যাপের নাম/প্যাকেজ দিয়ে Facebook clone শনাক্ত করার চেষ্টা করে।
